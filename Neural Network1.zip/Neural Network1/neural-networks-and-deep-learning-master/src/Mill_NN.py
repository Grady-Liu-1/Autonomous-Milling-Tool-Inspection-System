# -*- coding: utf-8 -*-
"""
Created on Sun Jun 24 18:07:56 2018

@author: grady
"""

import mnist_loader
training_data, validation_data, test_data = \
mnist_loader.load_data_wrapper()
import network
#import network2

net = network.Network([784, 30, 1])
net.SGD(training_data,10,2,3.0,test_data=test_data)

#net = network.Network([784, 30, 10])

#print (net.weights[1])
#print (net.biases[1])
#net.evaluate(test_data)
