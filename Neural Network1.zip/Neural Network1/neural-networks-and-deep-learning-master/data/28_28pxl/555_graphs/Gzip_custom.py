# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 16:51:18 2018

@author: grady
"""

import cPickle
import gzip
#import random
import numpy as np
import shutil
import scipy.io as sio
#from PIL import Image

mat_contents=sio.loadmat('data_2.mat')

incomingarray=np.ndarray(shape=(140,308025),dtype='f')
incomingarray=mat_contents['NewFM']

Test=np.ndarray(shape=(12,308025),dtype='f')
Test_res=np.ndarray(shape=(12,1),dtype='f')
Valid=np.ndarray(shape=(16,308025),dtype='f')
Valid_res=np.ndarray(shape=(16,1),dtype='f')
Train=np.ndarray(shape=(112,308025),dtype='f')
Train_res=np.ndarray(shape=(112,1),dtype='f')

k=0
while (k<140):
  if k<12:
    Test[k]=incomingarray[k]
  elif k>=12 and k<28:
    Valid[k-12]=incomingarray[k]
  elif k>=28 and k<140:
    Train[k-28]=incomingarray[k]
  k=k+1
   
f=open("VBdata.txt","r")
Data=[]
AA=0
while AA<167:
  Data.append(AA)
  Data[AA]=f.readline()
  AA=AA+1
z=0
Baddata=0
count=0
count2=0
count3=0
while z<167:
  if z not in [1,2,4,15,18,22,32,62,77,84,87,94,95,97,103.110,116,123,125,127,130,131,145,149,154,161,162,164]:
    if z<16:
      Test_res[count,0]=Data[z]
      count=count+1
    elif z>=16 and z<35:
      Valid_res[count2,0]=Data[z]
      count2=count2+1
    elif z>=35 and z<166:
      Train_res[count3,0]=Data[z]
      count3=count3+1
  z=z+1

f.close()
Test_fin=(Test,Test_res)
Valid_fin=(Valid,Valid_res)
Train_fin=(Train,Train_res)


data=file('large_555res.pkl','wb')
cPickle.dump((Train_fin,Valid_fin,Test_fin),data,protocol=cPickle.HIGHEST_PROTOCOL)
data.close()

with open('large_555res.pkl','rb') as f_in, gzip.open('large_555res.pkl.gz','wb') as f_out:
    shutil.copyfileobj(f_in,f_out)




print 'done'