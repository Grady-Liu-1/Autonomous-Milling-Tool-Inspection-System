function array_gen()

myFolder='H:\Summer Research Tutorial\Neural Network1\neural-networks-and-deep-learning-master\data\28_28pxl\555_graphs'
if ~isdir(myFolder)
    errorMessage=sprintf('Error');
    uiwait(warndlg(errorMessage));
    return;
end

filepat=fullfile(myFolder,'*.png');
pngFiles=dir(filepat);
i=1;
for k=1:length(pngFiles)
    baseFileName=pngFiles(k).name;
    fullFileName=fullfile(myFolder,baseFileName);
    imageArray=imread(fullFileName);
    newim=im2bw(imageArray);
    totalim=reshape(newim,[308025,1]);
    ntotalim=transpose(totalim);
    
    if k==1
        B2=pngFiles(k+1).name;
        FN=fullfile(myFolder,B2);
        imageArray1=imread(fullFileName);
        newim2=im2bw(imageArray1);
        totalim2=reshape(newim2,[308025,1]);
        temp=transpose(totalim2);
        FullMat=cat(1,ntotalim,temp);
    else
        FullMat=cat(1,FullMat,ntotalim);
    end
    
    
    i=i+1;
    k
end

NewFM=double(FullMat);
save('data_2.mat','NewFM')
out='done'
end