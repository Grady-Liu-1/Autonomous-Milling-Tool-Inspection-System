# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 01:26:37 2018

@author: grady
"""

import cPickle
import gzip
#import random
import numpy as np
import shutil
#from PIL import Image
from test2 import imageprepare

total=167

Testing=np.ndarray(shape=(12,308025),dtype='f')
Test_res=np.ndarray(shape=(12,1),dtype='f')
#Test=np.ndarray(shape=(2,1),dtype=object)



Validation=np.ndarray(shape=(16,308025),dtype='f')
Valid_res=np.ndarray(shape=(16,1),dtype='f')

Training=np.ndarray(shape=(112,308325),dtype='f')
Train_res=np.ndarray(shape=(112,1),dtype='f')

f=open("VBdata.txt","r")
temp= '../data/28_28pkl/'
Bad=0
y=0
z=0
count2=0
AA=0
Data=[]
while AA<167:
  Data.append(AA)
  Data[AA]=f.readline()
  AA=AA+1

while z<16:
    if (z==1) or (z==2) or (z==4) or (z==15):
      Bad=Bad+1
    else:
      FName=str(count2+1)+" graph.png"
      Temp2=imageprepare(FName)
      Test_res[count2,0]=Data[z]
      for k in range(784):
        Testing[count2,k]=Temp2[k]
      count2=count2+1
    z=z+1


bg=0
count=0

while z<35:
  if (z==22) or (z==18) or (z==32):
    bg=bg+1
  else:
#    print count
    FName2=str(z)+" graph.png"
    Temp3=imageprepare(FName2)
    Valid_res[count,0]=Data[z]
    for k in range(784):
        Validation[count,k]=Temp3[k]
    count=count+1
  z=z+1




##set training array to have an array of 
count=0
while z<167:
  if(z==77) or (z==84) or (z==87) or (z==94) or (z==94) or (z==97) or (z==103) or (z==123) or (z==127) or (z==130) or (z==131) or (z==145) or (z==149) or (z==149) or (z==154) or (z==161) or (z==162) or (z==164) or (z==62) or (z==95) or (z==110) or(z==116)or(z==125):
    bg=bg+1
  else:
    FName3=str(z)+" graph.png"
    Temp4=imageprepare(FName3)
    Train_res[count,0]=Data[z]
    for k in range(784):
        Training[count,k]=Temp4[k]
    count=count+1
  z=z+1

f.close()
#
Test_fin=(Testing,Test_res)
Valid_fin=(Validation,Valid_res)
Train_fin=(Training,Train_res)


data=file('Try1.pkl','wb')
cPickle.dump((Train_fin,Valid_fin,Test_fin),data,protocol=cPickle.HIGHEST_PROTOCOL)
data.close()

with open('Try1.pkl','rb') as f_in, gzip.open('Try1.pkl.gz','wb') as f_out:
    shutil.copyfileobj(f_in,f_out)
    
print "done"
