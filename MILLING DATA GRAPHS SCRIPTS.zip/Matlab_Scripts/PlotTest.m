function PlotTest()

data=load('mill.mat');
num_bins=50;
sample_size=9000/num_bins;

k=1;
while (k<=167)
    name(k,2)="graph.png";
    name(k,1) =int2str(k);
   
    
    k=k+1;
end    

newStr = join(name);

n=100;
k=1;
num=1;
Badplots=0;
type1=[0 0 0]; % black square
type2=[1 1 1]; % white square
% set(groot,'defaultFigureVisible','off');

while(n<=167) 
    figure(n);
    if ((n==18)||(n==32)||(n==62)||(n==95)||(n==110)||(n==116)||(n==125))
        Badplots=Badplots+1;
    else
    FW=data.mill(n).VB;
    ac=data.mill(n).smcAC;
    dc=data.mill(n).smcDC;
    VT=data.mill(n).vib_table;
    VS=data.mill(n).vib_spindle;
    AT=data.mill(n).AE_table;
    AS=data.mill(n).AE_spindle;
    DOC(n,1)=data.mill(n).DOC;
    FEED(n,1)=data.mill(n).feed;
    MAT(n,1)=data.mill(n).material;    
        
        
    nn=1;
    for qq=1:num_bins
        for ss=1:sample_size
        AS_M(ss,qq)=AS(nn);
        nn=nn+1;
        end
    end
    
    nn=1;
    for qq=1:num_bins
        for ss=1:sample_size
        ac_M(ss,qq)=ac(nn);
        nn=nn+1;
        end
    end
    
    nn=1;
    for qq=1:num_bins
        for ss=1:sample_size
        dc_M(ss,qq)=dc(nn);
        nn=nn+1;
        end
    end
    
    nn=1;
    for qq=1:num_bins
        for ss=1:sample_size
        VT_M(ss,qq)=VT(nn);
        nn=nn+1;
        end
    end
    
    nn=1;
    for qq=1:num_bins
        for ss=1:sample_size
        VS_M(ss,qq)=VS(nn);
        nn=nn+1;
        end
    end
    
    nn=1;
    for qq=1:num_bins
        for ss=1:sample_size
        AT_M(ss,qq)=AT(nn);
        nn=nn+1;
        end
    end     
%tightsubplot method
[ha,pos]=tight_subplot(3,3,0.00000001,0,0);
         for ii=1:9
            axes(ha(ii));
            if (ii==1)
                boxplot(ac_M,'Datalim',[-7,7],'ExtremeMode','clip','Symbol','','Colors',[0 0 0]);
            elseif (ii==2)
                boxplot(dc_M,'Datalim',[1,10],'ExtremeMode','clip','Symbol','','Colors',[0 0 0]);
            elseif (ii==3)
                boxplot(VT_M,'Datalim',[0,5],'ExtremeMode','clip','Symbol','','Colors',[0 0 0]);
            elseif (ii==4)
                boxplot(VS_M,'Datalim',[0,2.5],'ExtremeMode','clip','Symbol','','Colors',[0 0 0]);
            elseif (ii==5)
                boxplot(AT_M,'Datalim',[0,1.5],'ExtremeMode','clip','Whisker',0,'Symbol','','Colors',[0 0 0]);
            elseif (ii==6)
                boxplot(AS_M,'Datalim',[0,1],'ExtremeMode','compress','Symbol','','Colors',[0 0 0]);
            elseif (ii==7)
                if (DOC(n,1)==1.5)
                    rectangle('position',[0,0,1,1],'FaceColor',type1);
                    rectangle('position',[1,0,1,1],'FaceColor',type2);
                else
                    rectangle('position',[0,0,1,1],'FaceColor',type2);
                    rectangle('position',[1,0,1,1],'FaceColor',type1);   
                end
            elseif (ii==8)
                if (FEED(n,1)==0.5)
                    rectangle('position',[0,0,1,1],'FaceColor',type1);
                    rectangle('position',[1,0,1,1],'FaceColor',type2);
                else
                    rectangle('position',[0,0,1,1],'FaceColor',type2);
                    rectangle('position',[1,0,1,1],'FaceColor',type1);   
                end

            elseif (ii==9)
                if (MAT(n,1)==2)
                    rectangle('position',[0,0,1,1],'FaceColor',type1);
                    rectangle('position',[1,0,1,1],'FaceColor',type2);
                else
                    rectangle('position',[0,0,1,1],'FaceColor',type2);
                    rectangle('position',[1,0,1,1],'FaceColor',type1);   
                end

            end
             set(ha(1:9),'XTickLabel',''); set(ha,'YTickLabel','');
         end

    tightfig;
    set(gcf,'PaperUnits','inches','PaperPosition',[0,0,3.7,3.7]);
    %set(gcf,'PaperUnits','inches','PaperPosition',[0,0,0.19,0.19]);
    %result=imbinarize(gcf);
    saveas(gcf,newStr(n,1));
      
   end
     n=n+1;
end 

end
